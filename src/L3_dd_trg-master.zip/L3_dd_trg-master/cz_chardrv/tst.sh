dd if=/dev/czero of=/dev/cnul bs=8k count=8
